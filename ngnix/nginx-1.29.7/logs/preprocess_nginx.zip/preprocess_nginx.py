import pandas as pd
import os
import re

log_paths = [
    "lb_access.log",
    "access.log",
    "C:/ngnix/nginx-1.29.7/logs/lb_access.log",
    "C:/ngnix/nginx-1.29.7/logs/access.log"
]

log_file = None

for path in log_paths:
    if os.path.exists(path):
        log_file = path
        break

if log_file is None:
    raise FileNotFoundError("로그 파일을 찾을 수 없습니다.")

data = []

pattern = re.compile(
    r'(?P<ip>\S+) - - \[(?P<time>[^\]]+)\] "(?P<method>\S+) (?P<url>\S+) \S+" (?P<status>\d+) (?P<size>\d+)'
)

with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        match = pattern.search(line)
        if not match:
            continue

        try:
            time_raw = match.group("time")
            time = time_raw.split(":")[1] + ":" + time_raw.split(":")[2]

            status = int(match.group("status"))
            response_time = int(match.group("size"))

            server = "nginx"

            data.append([time, server, response_time, status])
        except:
            continue

df = pd.DataFrame(data, columns=["time", "server", "response_time", "status"])

df["time"] = df["time"].str[:5]
df["error"] = df["status"] >= 500

basic = df.groupby(["time", "server"]).agg(
    request_count=("time", "count"),
    avg_response_time=("response_time", "mean"),
    error_rate=("error", "mean")
).reset_index()

extra = df.groupby(["time", "server"]).agg(
    max_response_time=("response_time", "max"),
    min_response_time=("response_time", "min"),
    success_rate=("error", lambda x: 1 - x.mean())
).reset_index()

final = pd.merge(basic, extra, on=["time", "server"])

final.to_csv("processed_data.csv", index=False)

print(f"사용된 로그 파일: {log_file}")
print(final)
print("전처리 완료")
